data:extend({
  {
    type = "sprite",
    name = "edit-blueprints-button",
    filename = "__Edit-Blueprints__/graphics/icons/edit-blueprints-button-26.png",
    size = 26,
  }
})