-------------------------------------------------------------------------------
-- Class to build pin tab dialog
--
-- @module StatusPanel
-- @extends #Form
--

StatusPanel = newclass(Form)

-------------------------------------------------------------------------------
-- On initialization
--
-- @function [parent=#StatusPanel] onInit
--
function StatusPanel:onInit()
  self.panelCaption = ({"helmod_status-tab-panel.title"})
end

-------------------------------------------------------------------------------
-- Get or create info panel
--
-- @function [parent=#StatusPanel] getInfoPanel
--
function StatusPanel:getInfoPanel()
  local flow_panel, content_panel, menu_panel = self:getPanel()
  if content_panel["info-panel"] ~= nil and content_panel["info-panel"].valid then
    return content_panel["info-panel"]["scroll-panel"]
  end
  local mainPanel = GuiElement.add(content_panel, GuiFrameV("info-panel"):style(helmod_frame_style.panel))
  mainPanel.style.horizontally_stretchable = true
  return GuiElement.add(mainPanel, GuiScroll("scroll-panel"))
end

-------------------------------------------------------------------------------
-- Get or create header panel
--
-- @function [parent=#StatusPanel] getHeaderPanel
--
function StatusPanel:getHeaderPanel()
  local flow_panel, content_panel, menu_panel = self:getPanel()
  if content_panel["header"] ~= nil and content_panel["header"].valid then
    return content_panel["header"]
  end
  return GuiElement.add(content_panel, GuiFrameH("header"):style(helmod_frame_style.panel))
end

-------------------------------------------------------------------------------
-- On open
--
-- @function [parent=#StatusPanel] onOpen
--
-- @param #LuaEvent event
--
function StatusPanel:onOpen(event)
  self:updateHeader(event)
  self:getInfoPanel()
end

-------------------------------------------------------------------------------
-- On update
--
-- @function [parent=#StatusPanel] onUpdate
--
-- @param #LuaEvent event
--
function StatusPanel:onUpdate(event)
  self:updateInfo(event)
end

-------------------------------------------------------------------------------
-- Update information
--
-- @function [parent=#StatusPanel] updateInfo
--
-- @param #LuaEvent event
--
function StatusPanel:updateHeader(event)
  local header_panel = self:getHeaderPanel()
  local model = Model.getModel()

  GuiElement.add(header_panel, GuiButton(self.classname, "CLOSE"):sprite("menu", "close-white", "close"):style("helmod_button_menu_red"):caption({"helmod_button.close"}))
  GuiElement.add(header_panel, GuiButton(self.classname.."=UPDATE"):sprite("menu", "refresh-white", "refresh"):style("helmod_button_menu"):caption({"helmod_result-panel.refresh-button"}))

end

-------------------------------------------------------------------------------
-- Update information
--
-- @function [parent=#StatusPanel] updateInfo
--
-- @param #LuaEvent event
--
function StatusPanel:updateInfo(event)
  local info_panel = self:getInfoPanel()
  local model = Model.getModel()

  info_panel.clear()

  local column = 2

  local resultTable = GuiElement.add(info_panel, GuiTable("list-data"):column(column):style("helmod_table-odd"))
  --self:addProductionBlockHeader(resultTable)
  local elements = {}
  
  table.insert(elements, {name = "locomotive", type = "entity", value = #Player.getForce().get_trains()})
  
  local entities = {"logistic-robot", "construction-robot", "straight-rail", "curved-rail", "electric-furnace",
                    "assembling-machine-3", "chemical-plant", "oil-refinery", "beacon", "lab", "electric-mining-drill",
                    "express-transport-belt", "express-underground-belt", "express-splitter"
                    , "medium-electric-pole", "big-electric-pole"}
  for _, element in pairs(entities) do
    table.insert(elements, {name = element, type = "entity", value = Player.getForce().get_entity_count(element)})
  end
  
  for _, element in pairs(elements) do
    self:addProductionBlockRow(resultTable, element)
  end
end

-------------------------------------------------------------------------------
-- Add header data tab
--
-- @function [parent=#StatusPanel] addProductionBlockHeader
--
-- @param #LuaGuiElement itable container for element
--
function StatusPanel:addProductionBlockHeader(itable)
end

-------------------------------------------------------------------------------
-- Add row data tab
--
-- @function [parent=#StatusPanel] addProductionBlockRow
--
-- @param #LuaGuiElement guiTable
-- @param #table element
--
function StatusPanel:addProductionBlockRow(guiTable, element)
  GuiElement.add(guiTable, GuiButtonSprite("element", element.name):sprite(element.type, element.name):tooltip(Player.getLocalisedName(element)))
  GuiElement.add(guiTable, GuiLabel("value", element.name):caption(element.value))

end

-------------------------------------------------------------------------------
-- On event
--
-- @function [parent=#StatusPanel] onEvent
--
-- @param #LuaEvent event
--
function StatusPanel:onEvent(event)
end
